CREATE OR REPLACE VIEW CUX_APP_MUTIL_TEST_V AS
SELECT t.organization_id
      ,t.inventory_item_id
      ,t.segment1
      ,t.description
  FROM mtl_system_items_b t
 WHERE rownum < 20;
