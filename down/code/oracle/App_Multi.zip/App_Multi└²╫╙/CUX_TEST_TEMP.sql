-- Create table
create table CUX_TEST_TEMP
(
  ID     NUMBER,
  RESULT VARCHAR2(240)
)
tablespace APPS_TS_CUX_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
