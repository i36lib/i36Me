* From [https://i36.me/](https://i36.me/)

* 打包和构建

```shell
$ mvn install
$ mvn build
$ cp target/smvc-demo-1.0.0.war $TOMCAT_HOME/webapps/smvc.war
```

* 访问项目`http://localhost:8080/smvc/`
