/**
 * Copyright (c) 2020 https://i36.Me/
 */
package cn.xlibs.java.spring.mvc.demo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("cn.xlibs.java.spring.mvc.demo")
public class MvcConfig {
}
