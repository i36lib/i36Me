/**
 * Copyright (c) 2020 https://i36.Me/
 */
package cn.xlibs.java.spring.mvc.demo;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

public class WebXml implements WebApplicationInitializer {
    public void onStartup(ServletContext servletContext) throws ServletException {
        AnnotationConfigWebApplicationContext appContext = new AnnotationConfigWebApplicationContext();
        appContext.register(MvcConfig.class);

        ServletRegistration.Dynamic servletRegistration = servletContext.addServlet(
                "springmvc", new DispatcherServlet(appContext)
        );
        servletRegistration.addMapping("/");
        servletRegistration.setLoadOnStartup(1);
    }
}
