/**
 * Copyright (c) 2020 https://i36.Me/
 */
package cn.xlibs.java.spring.mvc.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/")
    public String helloWorld() {
        return "hello world";
    }
}
